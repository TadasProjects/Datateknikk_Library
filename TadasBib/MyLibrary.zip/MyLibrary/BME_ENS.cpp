#include "components.h"

Adafruit_BME280 bme;
SparkFun_ENS160 ens;

// BME startup
void bmeStartup() {
    bool ok = false;

    ok = bme.begin(0x76);      // first try 0x76
    if (!ok) {
        ok = bme.begin(0x77);  // then try 0x77
    }

    if (!ok) {
        Serial.println(F("Could not find a valid BME280 sensor, check wiring!"));
        while (1) {
            delay(10);
        }
    }
}

// ENS startup (SparkFun library)
void ensStartup() {
    if (!ens.begin()) {
        Serial.println(F("Could not find a valid ENS160 sensor, check wiring!"));
        while (1) {
            delay(10);
        }
    }

    // reset
    if (ens.setOperatingMode(SFE_ENS160_RESET)) {
        Serial.println("ENS ready");
    }

    delay(100);

    // BME compensation if BME is present
    if (bme.sensorID()) {
        float t = bme.readTemperature();
        float h = bme.readHumidity();

        ens.setTempCompensationCelsius(t);
        ens.setRHCompensationFloat(h);
    }

    // go to standard operating mode
    ens.setOperatingMode(SFE_ENS160_STANDARD);
}
