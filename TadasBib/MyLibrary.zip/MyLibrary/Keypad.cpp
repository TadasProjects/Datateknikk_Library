#include "components.h"

void Keypad::startUp(int amount, int keyPins[]) {
    for (int i = 0; i < amount; i++) {
        pins[i] = keyPins[i];
        pinMode(pins[i], INPUT_PULLUP);
    }
}

// -- Thease 2 define the pins, and makes them INPUT_PULLUP using the code above. >:!
void Keypad::define(int p1,int p2,int p3,int p4,int p5,int p6,int p7) {
    int k[] = {p1,p2,p3,p4,p5,p6,p7};
    amount = 7;
    startUp(amount, k);
}

void Keypad::define(int p1,int p2,int p3,int p4,int p5,int p6,int p7,int p8) {
    int k[] = {p1,p2,p3,p4,p5,p6,p7,p8};
    amount = 8;
    startUp(amount, k);
}

int Keypad::getAmount() { return amount; }

int Keypad::getPin(int index) { 
    return pins[index]; 
}

void Keypad::keyMaping() {
    const char keys[] = {'1','2','3','4','5','6','7','8','9','*','0','#'};
    
    for (char key : keys) {
        Serial.print("looking for ");
        Serial.println(key);

        bool keyScanned = false;

        while (!keyScanned) {           
            int count = getAmount();
        
            for (int driveIndex = 0; driveIndex < count; driveIndex++) {
                for (int i = 0; i < count; i++) {
                    int pin = getPin(i);
                
                    if (i == driveIndex) {
                        pinMode(pin, OUTPUT);
                        digitalWrite(pin, LOW);
                    } else {
                        pinMode(pin, INPUT_PULLUP);
                    }
                }

                for (int readIndex = 0; readIndex < count; readIndex++) {
                    if (readIndex == driveIndex) continue;
                    int readPin = getPin(readIndex);

                    if (digitalRead(readPin) == LOW) {
                        int drivePin = getPin(driveIndex);

                        Serial.print("Key ");
                        Serial.print(key);
                        Serial.print(" connects pin ");
                        Serial.print(drivePin);
                        Serial.print(" <-> ");
                        Serial.println(readPin);

                        keyScanned = true;   // now we found it

                        while (digitalRead(readPin) == LOW) {
                            delay(5);        // wait for release
                        }
                        break;
                    }
                }

                if (keyScanned) break;
            }

            delay(5);
        }
    }
}
